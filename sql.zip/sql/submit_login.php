<?php
session_start();
if(isset($_SESSION['user'])){
    header("Location: liste.cpg" );
}
include 'db.php';
$username=$_POST['username'];
$password=$_POST['password'];
$sql = "SELECT * FROM utilisateurs WHERE nom_utilisateur='$username' AND mot_de_passe='$password'";
$result = mysqli_query($cnx, $sql);
if (mysqli_num_rows($result) > 0) {
  $_SESSION['user'] = mysqli_fetch_assoc($result);
  header('Location:liste.cpg');
} else {
  echo "Cordonnés incorrectes ,veillez réessayer, <a href='authentification.cpg'>retour</a>.";
}