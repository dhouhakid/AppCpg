<html>
    <head>
        <title>CPG - Gestion des voyages de phosphate</title>
        <link rel="stylesheet" type=text/css href="index.css">
</head>
<?php
include "db.php";
$id = $_GET['id'];
$q = mysqli_query($cnx,"SELECT * FROM voyages WHERE id=$id");
$result = mysqli_query($cnx, "SELECT * FROM voyages WHERE ID_voyage=$id");
$v = mysqli_fetch_assoc($result);
if (isset($_POST['modifier'])){
$d = $_POST['date'];
$des = $_POST['dest'];
$type = $_POST['type'];
$requete3 = "UPDATE voyages SET Date_voyage = '$d',Type_voyage='$type',Destination_voyage='$des' WHERE ID_voyage = '$id'";
$res = mysqli_query($cnx,$requete3);
if ($res){
    echo "voyage a était modifié avec succés";
    sleep(3);
    header('Location:liste.cpg');
}else {
    echo "voyage n'est pas modifié";
}
}

?>

<div >
    <button class="liste"><a href="liste.cpg">Voir la  liste des voyages</a></button>
</div>
<h1>Modifier un voyage</h1>
<form method="post">
    <pre>
Date voyage :

<input type="date" name="date" size="20" value="<?php echo $v['Date_voyage']?>"></input>

Type voyage :

<input type="text" name="type" size="20" value="<?=$v['Type_voyage'];?>"></input>

Destination voyage :

<input type="text" name="dest" size="20" value="<?=$v['Destination_voyage'];?>"></input>

<button name="modifier" class="add">Modifier</button>  <input type="reset" value="annuler"/>

</pre>  
</form>