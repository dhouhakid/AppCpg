<?php
session_start();
if (isset($_SESSION['user'])) {
    header('location:liste.cpg');
}
include "db.php";
?>
<html>
<head>
    <title>CPG - Authentification</title>
    <link rel="stylesheet" type="text/css" href="index.css">
    <style>

    </style>
</head>
<body>
<center> <h1>Connectez-vous</h1>
    <form action="submit_login.cpg" method="POST">
        <input type="text" name="username" placeholder="Nom d'utilisateur" required><br>
        <input type="password" name="password" placeholder="Mot de passe" required><br>
        <input type="submit" value="Se connecter">
    </form>
</center>
</body>
</html>