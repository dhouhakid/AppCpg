<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('location:authentification.cpg');
}
if (isset($_GET['logout'])) {
    session_unset();
    header('Location:authentification.cpg');
}
include "db.php";
?>
<html>
<head>

        <title>CPG - Gestion des voyages de phosphate</title>
<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
<h2>Bienvenue <?php echo $_SESSION['user']['prenom'] . ' ' . $_SESSION['user']['nom'] ?>,<div class="right"> <a href="?logout">déconnexion</a></div>
<center>
<h2>Listes des voyages</h2>
 <table border='1'> 
<tr>
<th>ID VOYAGE</th>
<th>Date Voyage</th>
<th>Type Voyage</th>
<th>Destination Voyage</th>
<th colspan=2></th>
</tr> 


<?php
$requete1 = "SELECT * FROM voyages";
$res = mysqli_query($cnx,$requete1);
while ($row = mysqli_fetch_array($res)) {
    echo "<tr>";
    echo "<td>$row[ID_voyage]</td>";
    echo "<td>".date('d-m-Y',strtotime($row['Date_voyage']))."</td>";
    echo "<td>$row[Type_voyage]</td>";
    echo "<td>$row[Destination_voyage]</td>";
    echo "<td><a href='modifier_voyage_$row[ID_voyage].cpg'>Modifier voyage</a></td>";
    echo "<td><a href='supprimer_voyage_$row[ID_voyage].cpg'>Supprimer voyage</a></td>";
    echo "</tr>";
   // $nb=$row['NBV'];
//echo "$row[ID_voyage]";
}
//$_SESSION['NBV']=$nb;
//echo"Nombre total des voyages : $_SESSION[NBV]";
?>

</table><br>
<a href="ajouter_voyage.cpg">Ajouter un voyage</a>
</center>
</body>
</html>