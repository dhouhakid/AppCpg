<html>
    <head>
        <title>CPG - Gestion des voyages de phosphate</title>
        <link rel="stylesheet" type="text/css" href="index.css">
</head>
<?php
include "db.php";
if (isset($_POST['add'])){
$d = $_POST['date'];
$des = $_POST['dest'];
$type = $_POST['type'];
if ($_POST['date'] == '' || $_POST['dest'] == '' || $_POST['type'] == '') { echo "fill the form";} else {
$requete2 = "INSERT INTO voyages VALUES(NULL,'$d','$des','$type')";
$res = mysqli_query($cnx,$requete2);
if ($res){
    echo "voyage a était ajouté avec succés";
}else {
    echo "voyage n'est pas ajouté";
}
}

}

?>
<div >
    <button class="liste"><a href="liste.php">Voir la  liste des voyages</a></button>
</div>
<div >
<h1>Ajouter un voyage</h1>
<div>
<form method="post" action="ajouter.php">
    <pre>
Date voyage :

<input type="date" name="date" size="20"></input>

Type voyage :

<input type="text" name="type" size="20"></input>

Destination voyage :

<input type="text" name="dest" size="20"></input>

<button name="add" class="add">Ajouter</button>  <input type="reset" value="annuler"/>

</pre>  
</form>
</html>