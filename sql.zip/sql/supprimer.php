<html>
    <head>
        <title>CPG - Gestion des voyages de phosphate</title>
        <link rel="stylesheet" href="index.css">
</head>
<?php
include "db.php";
$id = $_GET['id'];
$requete4 = "DELETE FROM voyages WHERE ID_voyage = '$id'";
$resultat = mysqli_query($cnx,$requete4);
if ($resultat) {
    echo "voyage a était supprimé avec succés <a href='liste.cpg'>retour</a>";
}else {
    echo "voyage n'est pas supprimé";
}

?>